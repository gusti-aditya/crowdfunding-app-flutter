<?php

namespace App\Controllers;
use Exception;
use CodeIgniter\RESTful\ResourceController;
use App\Models\Users;
use Firebase\JWT\JWT;

class UsersController extends ResourceController
{
    // POST
	public function userRegister()
	{
		$rules = [
			"first_name" => "required",
			"last_name" => "required",
			"email" => "required|valid_email[users.email]",
			"password" => "required"
		];

		if (!$this->validate($rules)) {
			// error
			$response = [
				"status" => 500,
				"message" => $this->validator->getErrors(),
				"error" => true,
				"data" => []
			];
		} else {
			// no error
			$user_obj = new Users();
            $hashPassword = password_hash($this->request->getVar("password"),PASSWORD_DEFAULT);

			$data = [
                "customer_id" => uniqid(),
				"first_name" => $this->request->getVar("first_name"),
				"last_name" => $this->request->getVar("last_name"),
				"email" => $this->request->getVar("email"),
				"password" => $hashPassword
			];

			if ($user_obj->insert($data)) {
				// success
				$response = [
					"status" => 200,
					"message" => "User has been registered",
					"error" => false,
					"data" => []
				];
			} else {
				// failed to insert
				$response = [
					"status" => 500,
					"message" => "Failed to register user",
					"error" => true,
					"data" => []
				];
			}
		}

		return $this->respondCreated($response);
	}

	// POST
	public function userLogin()
	{
		$rules = [
			"email" => "required|valid_email",
			"password" => "required"
		];

		if (!$this->validate($rules)) {
			// error
			$response = [
				"status" => 500,
				"message" => $this->validator->getErrors(),
				"error" => true,
				"data" => []
			];
		} else {
			// no error
			$email = $this->request->getVar("email");
			$password = $this->request->getVar("password");

			$user_obj = new Users();

			$userdata = $user_obj->where("email", $email)->first();

			if (!empty($userdata)) {
				// user exists

				if (password_verify($password, $userdata['password'])) {
					// user details matched

					$iat = time();
					$nbf = $iat + 10;
					$exp = $iat + 300;

					$payload = [
						"iat" => $iat,
						"nbf" => $nbf,
						"exp" => $exp,
						"userdata" => $userdata
					];

					$token = JWT::encode($payload, $this->getKey(),'HS256');

					$response = [
						"status" => 200,
						"message" => "User logged in",
						"error" => false,
						"data" => [
							"token" => $token
						]
					];
				} else {
					// password didnt match
					$response = [
						"status" => 500,
						"message" => "Password didn't match",
						"error" => true,
						"data" => []
					];
				}
			} else {
				// user doesnot exists
				$response = [
					"status" => 500,
					"message" => "Invalid details",
					"error" => true,
					"data" => []
				];
			}
		}

		return $this->respondCreated($response);
	}

	public function getKey()
	{
		return "gelatohouse2022";
	}

	// GET
	public function userProfile()
	{
		$auth = $this->request->getHeader("Authorization");

		try {

			if (isset($auth)) {

				$token = $auth->getValue();

				$decoded_data = JWT::decode($token, $this->getKey(), array("HS256"));

				$response = [
					"status" => 200,
					"message" => "User profile data",
					"error" => false,
					"data" => [
						"user" => $decoded_data,
						"id" => $decoded_data->userdata->id
					]
				];
			} else {

				$response = [
					"status" => 500,
					"message" => "User must be login",
					"error" => true,
					"data" => []
				];
			}
		} catch (Exception $ex) {

			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];
		}

		return $this->respondCreated($response);
	}
}
