<?php

namespace App\Controllers;
use Exception;
use CodeIgniter\RESTful\ResourceController;
use App\Models\Business;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;


class BusinessController extends ResourceController
{

	public function getKey()
	{
		return "gelatohouse2022";
	}

	// GET
	public function listBusiness()
	{
		try {

			$auth = $this->request->header("Authorization");

			$token = $auth->getValue();
			$payload = [
				'token' => $token
			];
			
			$jwt = JWT::encode($payload, $this->getKey(), 'HS256');


			$decoded_data = JWT::decode($jwt, new Key($this->getKey(),'HS256'));


			$business_obj = new Business();

			$business_data = $business_obj->findAll();

			$response = [
				"status" => 200,
				"message" => "Business list",
				"error" => false,
				"data" => $business_data
			];

			return $this->respondCreated($response);
		} catch (Exception $ex) {

			$response = [
				"status" => 500,
				"message" => $ex->getMessage(),
				"error" => true,
				"data" => []
			];

			return $this->respondCreated($response);
		}

		return $this->respondCreated($response);
	}
}
